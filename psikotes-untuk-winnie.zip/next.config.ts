import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* config options here */
  basePath: '/winnieloveuu',
  trailingSlash: true,
};

export default nextConfig;