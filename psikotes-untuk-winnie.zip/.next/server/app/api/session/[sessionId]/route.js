var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/session/[sessionId]/route.js")
R.c("server/chunks/[root-of-the-server]__fc8e2828._.js")
R.c("server/chunks/[root-of-the-server]__9aaf4e23._.js")
R.c("server/chunks/62acc__next-internal_server_app_api_session_[sessionId]_route_actions_ffd96ebc.js")
R.m(5661)
module.exports=R.m(5661).exports
