var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/generate-questions/route.js")
R.c("server/chunks/[root-of-the-server]__522e24c4._.js")
R.c("server/chunks/[root-of-the-server]__79812305._.js")
R.c("server/chunks/[root-of-the-server]__9aaf4e23._.js")
R.c("server/chunks/62acc__next-internal_server_app_api_generate-questions_route_actions_b96ebdac.js")
R.m(38122)
module.exports=R.m(38122).exports
