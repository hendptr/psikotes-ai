var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__9aaf4e23._.js")
R.c("server/chunks/7875c_next_dist_esm_build_templates_app-route_9e527377.js")
R.c("server/chunks/62acc__next-internal_server_app_favicon_ico_route_actions_6e568c63.js")
R.m(50787)
module.exports=R.m(50787).exports
