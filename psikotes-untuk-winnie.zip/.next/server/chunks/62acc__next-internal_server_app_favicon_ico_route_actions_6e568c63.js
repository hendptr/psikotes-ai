module.exports=[45052,(e,o,d)=>{}];

//# sourceMappingURL=62acc__next-internal_server_app_favicon_ico_route_actions_6e568c63.js.map