module.exports=[1759,(e,o,d)=>{}];

//# sourceMappingURL=62acc__next-internal_server_app_api_generate-questions_route_actions_b96ebdac.js.map