module.exports=[8309,(a,b,c)=>{}];

//# sourceMappingURL=62acc__next-internal_server_app__global-error_page_actions_52e77736.js.map