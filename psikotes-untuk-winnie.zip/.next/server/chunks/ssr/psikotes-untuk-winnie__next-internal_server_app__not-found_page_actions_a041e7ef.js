module.exports=[13640,(a,b,c)=>{}];

//# sourceMappingURL=psikotes-untuk-winnie__next-internal_server_app__not-found_page_actions_a041e7ef.js.map