module.exports=[35547,(a,b,c)=>{}];

//# sourceMappingURL=psikotes-untuk-winnie__next-internal_server_app_test_page_actions_9587bfc9.js.map