module.exports=[12834,(a,b,c)=>{}];

//# sourceMappingURL=psikotes-untuk-winnie__next-internal_server_app_page_actions_e73422a4.js.map