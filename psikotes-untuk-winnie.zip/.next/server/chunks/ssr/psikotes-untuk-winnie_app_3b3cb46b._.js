module.exports=[51887,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},42199,a=>{"use strict";let b={src:a.i(51887).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=psikotes-untuk-winnie_app_3b3cb46b._.js.map