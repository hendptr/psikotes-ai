globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/7875c_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_67e51508._.js",
    "static/chunks/7875c_next_dist_compiled_react-dom_96e9b84a._.js",
    "static/chunks/7875c_next_dist_compiled_react-server-dom-turbopack_062e639f._.js",
    "static/chunks/7875c_next_dist_compiled_next-devtools_index_16c19d27.js",
    "static/chunks/7875c_next_dist_compiled_7cc44645._.js",
    "static/chunks/7875c_next_dist_client_45b16614._.js",
    "static/chunks/7875c_next_dist_c035b8ca._.js",
    "static/chunks/7875c_@swc_helpers_cjs_91b722ea._.js",
    "static/chunks/psikotes-untuk-winnie_a0ff3932._.js",
    "static/chunks/turbopack-psikotes-untuk-winnie_b40310c9._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];