module.exports = [
"[project]/psikotes-untuk-winnie/node_modules/node-fetch/src/utils/multipart-parser.js [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/7875c_node-fetch_src_utils_multipart-parser_59dd649f.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/psikotes-untuk-winnie/node_modules/node-fetch/src/utils/multipart-parser.js [app-route] (ecmascript)");
    });
});
}),
];