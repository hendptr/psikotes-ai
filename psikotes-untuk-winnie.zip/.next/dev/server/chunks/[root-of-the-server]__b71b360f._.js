module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/child_process [external] (child_process, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("child_process", () => require("child_process"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/os [external] (os, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[externals]/process [external] (process, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("process", () => require("process"));

module.exports = mod;
}),
"[externals]/util [external] (util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/querystring [external] (querystring, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("querystring", () => require("querystring"));

module.exports = mod;
}),
"[externals]/buffer [external] (buffer, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}),
"[externals]/fs/promises [external] (fs/promises, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs/promises", () => require("fs/promises"));

module.exports = mod;
}),
"[externals]/node:stream [external] (node:stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:stream", () => require("node:stream"));

module.exports = mod;
}),
"[externals]/node:stream/promises [external] (node:stream/promises, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:stream/promises", () => require("node:stream/promises"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/net [external] (net, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("net", () => require("net"));

module.exports = mod;
}),
"[externals]/tls [external] (tls, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("tls", () => require("tls"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[project]/psikotes-untuk-winnie/app/api/generate-question/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// app/api/generate-question/route.ts
__turbopack_context__.s([
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/psikotes-untuk-winnie/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f40$google$2f$genai$2f$dist$2f$node$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/psikotes-untuk-winnie/node_modules/@google/genai/dist/node/index.mjs [app-route] (ecmascript)");
;
;
const ai = new __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f40$google$2f$genai$2f$dist$2f$node$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["GoogleGenAI"]({
    apiKey: process.env.GEMINI_API_KEY
});
function buildCategoryInstruction(category) {
    switch(category){
        case "padanan_kata":
            return `
Jenis soal: PADANAN KATA (hubungan arti).
- Berikan sepasang kata utama, lalu beberapa pasangan kata sebagai pilihan.
- Peserta diminta memilih pasangan yang HUBUNGAN katanya PALING MIRIP dengan pasangan utama.
- Contoh gaya (JANGAN dipakai persis): "Dokter : Rumah Sakit = ...".
`;
        case "sinonim_antonim":
            return `
Jenis soal: SINONIM / ANTONIM.
- Berikan satu kata utama.
- Tentukan apakah soal meminta SINONIM atau ANTONIM (pilih salah satu, bukan dua-duanya).
- Tulis jelas di soal, misalnya: "Pilih SINONIM yang paling tepat untuk kata berikut".
- Sediakan 4–5 pilihan jawaban.
`;
        case "hafalan_kata":
            return `
Jenis soal: HAFALAN KATA.
- Di awal soal, tampilkan 8–12 kata acak (boleh dibagi dalam 2–3 baris).
- Setelah itu beri pertanyaan yang menguji ingatan, misalnya:
  - "Kata mana yang TIDAK ada dalam daftar di atas?"
  - atau "Pasangan kata mana yang muncul berurutan di daftar?"
- Sediakan 4–5 pilihan jawaban.
`;
        case "deret_matematika":
            return `
Jenis soal: DERET MATEMATIKA SULIT.
- Fokus pada deret yang butuh penalaran, bukan hanya +2, +3 yang sederhana.
- Gunakan pola campuran: aritmetika, geometri, pola selang-seling, kombinasi huruf & angka, atau operasi berbeda di posisi ganjil/genap.
- Boleh gunakan LEBIH DARI SATU titik kosong, misal: 3, 6, __, 24, __, 96, ...
- Boleh gunakan huruf untuk mewakili posisi (misal: A, B, C) selama jelas.
- Pilihan jawaban harus berupa isi titik kosong yang benar (bisa satu nilai, atau pasangan nilai seperti "8 dan 48").
`;
        default:
            return "";
    }
}
async function POST(req) {
    if (!process.env.GEMINI_API_KEY) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: "GEMINI_API_KEY belum di-set di environment."
        }, {
            status: 500
        });
    }
    const body = await req.json();
    const category = body.category ?? "padanan_kata";
    const difficulty = body.difficulty ?? "sulit";
    const categoryInstruction = buildCategoryInstruction(category);
    const prompt = `
Kamu adalah generator soal psikotes kerja di Indonesia.

Tujuan:
- Buat 1 soal psikotes kategori: ${category}.
- Tingkat kesulitan: ${difficulty} (anggap untuk seleksi perusahaan besar).
- Bahasa: Indonesia, gaya baku / semi-baku.

${categoryInstruction}

Aturan umum:
- Soal harus terasa seperti soal psikotes resmi (bukan quiz santai).
- Selalu sediakan 4 atau 5 pilihan jawaban, label "A", "B", "C", "D", dan jika perlu "E".
- HANYA ada 1 jawaban yang benar.
- "questionText" cukup ringkas tapi jelas.
- "explanation" jelaskan:
  - Kenapa jawaban yang benar benar.
  - Kenapa pilihan lain salah / kurang tepat.

Return HASIL **hanya** dalam format JSON sesuai schema (tanpa teks tambahan):

{
  "category": string,              // misal: "padanan_kata"
  "difficulty": string,            // misal: "sulit"
  "questionType": string,          // misal: "padanan_kata_hubungan_arti"
  "questionText": string,          // teks soal yang ditampilkan
  "options": [
    { "label": "A", "text": string },
    { "label": "B", "text": string },
    ...
  ],
  "correctOptionLabel": string,    // misal: "C"
  "explanation": string            // penjelasan dalam bahasa Indonesia
}
`;
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            // JSON Mode + schema :contentReference[oaicite:2]{index=2}
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: "object",
                    properties: {
                        category: {
                            type: "string"
                        },
                        difficulty: {
                            type: "string"
                        },
                        questionType: {
                            type: "string"
                        },
                        questionText: {
                            type: "string"
                        },
                        options: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    label: {
                                        type: "string"
                                    },
                                    text: {
                                        type: "string"
                                    }
                                },
                                required: [
                                    "label",
                                    "text"
                                ]
                            }
                        },
                        correctOptionLabel: {
                            type: "string"
                        },
                        explanation: {
                            type: "string"
                        }
                    },
                    required: [
                        "category",
                        "difficulty",
                        "questionType",
                        "questionText",
                        "options",
                        "correctOptionLabel",
                        "explanation"
                    ]
                }
            }
        });
        const jsonText = response.text; // SDK Node.js expose .text untuk konten teks :contentReference[oaicite:3]{index=3}
        const parsed = JSON.parse(jsonText);
        return __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(parsed);
    } catch (err) {
        console.error("Gemini error:", err);
        return __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: "Gagal generate soal dari Gemini."
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__b71b360f._.js.map