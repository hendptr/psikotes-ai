module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/child_process [external] (child_process, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("child_process", () => require("child_process"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/os [external] (os, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[externals]/process [external] (process, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("process", () => require("process"));

module.exports = mod;
}),
"[externals]/util [external] (util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[externals]/querystring [external] (querystring, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("querystring", () => require("querystring"));

module.exports = mod;
}),
"[externals]/buffer [external] (buffer, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}),
"[externals]/fs/promises [external] (fs/promises, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs/promises", () => require("fs/promises"));

module.exports = mod;
}),
"[externals]/node:stream [external] (node:stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:stream", () => require("node:stream"));

module.exports = mod;
}),
"[externals]/node:stream/promises [external] (node:stream/promises, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:stream/promises", () => require("node:stream/promises"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/net [external] (net, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("net", () => require("net"));

module.exports = mod;
}),
"[externals]/tls [external] (tls, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("tls", () => require("tls"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[project]/psikotes-untuk-winnie/lib/session-store.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getSession",
    ()=>getSession,
    "listSessions",
    ()=>listSessions,
    "setSession",
    ()=>setSession,
    "updateSession",
    ()=>updateSession
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
;
;
const SESSION_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), ".tmp");
const SESSION_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(SESSION_DIR, "session-store.json");
const sessionStore = new Map();
let initialized = false;
let pendingSave = null;
async function ensureInitialized() {
    if (initialized) return;
    initialized = true;
    try {
        const buffer = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].readFile(SESSION_FILE, "utf8");
        const raw = JSON.parse(buffer);
        for (const record of raw){
            sessionStore.set(record.sessionId, record);
        }
    } catch (error) {
        // File may not exist on first run; ignore ENOENT.
        if (error?.code !== "ENOENT") {
            console.error("Failed to load session store:", error);
        }
    }
}
async function persistStore() {
    await ensureInitialized();
    await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].mkdir(SESSION_DIR, {
        recursive: true
    });
    const snapshot = Array.from(sessionStore.values());
    await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].writeFile(SESSION_FILE, JSON.stringify(snapshot, null, 2), "utf8");
}
function schedulePersist() {
    if (pendingSave) return;
    pendingSave = persistStore().catch((error)=>{
        console.error("Failed to persist session store:", error);
    }).finally(()=>{
        pendingSave = null;
    });
}
async function getSession(sessionId) {
    await ensureInitialized();
    return sessionStore.get(sessionId) ?? null;
}
async function setSession(record) {
    await ensureInitialized();
    sessionStore.set(record.sessionId, record);
    schedulePersist();
    return record;
}
async function updateSession(sessionId, updater) {
    await ensureInitialized();
    const current = sessionStore.get(sessionId) ?? null;
    const next = updater(current);
    if (!next) {
        if (sessionStore.has(sessionId)) {
            sessionStore.delete(sessionId);
            schedulePersist();
        }
        return null;
    }
    sessionStore.set(sessionId, next);
    schedulePersist();
    return next;
}
async function listSessions() {
    await ensureInitialized();
    return Array.from(sessionStore.values());
}
}),
"[project]/psikotes-untuk-winnie/app/api/generate-questions/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "POST",
    ()=>POST,
    "runtime",
    ()=>runtime
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$crypto__$5b$external$5d$__$28$crypto$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/crypto [external] (crypto, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/psikotes-untuk-winnie/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f40$google$2f$genai$2f$dist$2f$node$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/psikotes-untuk-winnie/node_modules/@google/genai/dist/node/index.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$lib$2f$session$2d$store$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/psikotes-untuk-winnie/lib/session-store.ts [app-route] (ecmascript)");
;
;
;
;
const runtime = "nodejs";
const ai = new __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f40$google$2f$genai$2f$dist$2f$node$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["GoogleGenAI"]({
    apiKey: process.env.GEMINI_API_KEY
});
const CACHE_TTL_MS = 1000 * 60 * 10; // 10 minutes
const questionCache = new Map();
function buildCategoryInstruction(category) {
    switch(category){
        case "padanan_kata":
            return `
Jenis soal: PADANAN KATA (hubungan arti).
- Berikan pasangan kata utama, lalu beberapa pasangan kata sebagai pilihan.
- Peserta diminta memilih pasangan yang hubungan katanya PALING MIRIP dengan pasangan utama.
- Contoh gaya (jangan digunakan persis): "Dokter : Rumah Sakit = ...".
`;
        case "sinonim_antonim":
            return `
Jenis soal: SINONIM / ANTONIM.
- Berikan satu kata utama.
- Tentukan apakah soal meminta SINONIM atau ANTONIM (pilih salah satu).
- Tuliskan jelas di soal, misalnya: "Pilih SINONIM yang paling tepat untuk kata berikut".
- Sediakan 4 sampai 5 pilihan jawaban.
`;
        case "hafalan_kata":
            return `
Jenis soal: HAFALAN KATA.
- Di awal soal, tampilkan 8 sampai 12 kata acak (boleh dibagi beberapa baris).
- Setelah itu beri pertanyaan yang menguji ingatan, misalnya:
  - "Kata mana yang TIDAK ada dalam daftar di atas?"
  - atau "Pasangan kata mana yang muncul berurutan di daftar?"
- Sediakan 4 sampai 5 pilihan jawaban.
`;
        case "deret_matematika":
            return `
Jenis soal: DERET MATEMATIKA SULIT.
- Fokus pada deret yang butuh penalaran, bukan hanya pola sederhana.
- Gunakan pola campuran: aritmetika, geometri, pola selang-seling, kombinasi huruf dan angka, atau operasi berbeda di posisi ganjil/genap.
- Boleh gunakan lebih dari satu titik kosong, misalnya: 3, 6, __, 24, __, 96, ...
- Boleh pakai huruf untuk mewakili posisi (A,B,C) selama jelas.
- Pilihan jawaban harus berupa isi titik kosong yang benar (boleh satu nilai, boleh dua nilai seperti "8 dan 48").
`;
        case "mixed":
        default:
            return `
Kategori CAMPURAN:
- Untuk setiap soal, pilih secara acak salah satu dari:
  - padanan_kata
  - sinonim_antonim
  - hafalan_kata
  - deret_matematika (sulit)
- Pastikan field "category" di JSON mencerminkan kategori aktual tiap soal.
`;
    }
}
function buildModeHint(userType) {
    switch(userType){
        case "simulasi":
            return "Mode ini seperti simulasi tes kerja sungguhan. Soal boleh dibuat agak menekan waktu dan menguji konsentrasi.";
        case "serius":
            return "Mode ini fokus untuk belajar serius dan memperkuat konsep psikotes.";
        case "tantangan":
            return "Mode ini adalah mode tantangan. Tingkatkan tingkat kesulitan soal dan dorong peserta untuk berpikir cepat dengan variasi pola yang tidak terduga.";
        default:
            return "Mode ini lebih santai, tapi tetap gunakan gaya soal psikotes resmi (bukan kuis santai).";
    }
}
function buildCacheKey(config) {
    return JSON.stringify([
        config.userType,
        config.category,
        config.difficulty,
        config.count
    ]);
}
async function generateQuestions(prompt) {
    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: "ARRAY",
                items: {
                    type: "OBJECT",
                    properties: {
                        category: {
                            type: "STRING"
                        },
                        difficulty: {
                            type: "STRING"
                        },
                        questionType: {
                            type: "STRING"
                        },
                        questionText: {
                            type: "STRING"
                        },
                        options: {
                            type: "ARRAY",
                            items: {
                                type: "OBJECT",
                                properties: {
                                    label: {
                                        type: "STRING"
                                    },
                                    text: {
                                        type: "STRING"
                                    }
                                },
                                required: [
                                    "label",
                                    "text"
                                ]
                            }
                        },
                        correctOptionLabel: {
                            type: "STRING"
                        },
                        explanation: {
                            type: "STRING"
                        }
                    },
                    required: [
                        "category",
                        "difficulty",
                        "questionType",
                        "questionText",
                        "options",
                        "correctOptionLabel",
                        "explanation"
                    ]
                }
            }
        }
    });
    const jsonText = response.text;
    if (!jsonText) {
        throw new Error("Respons kosong dari Gemini.");
    }
    const parsed = JSON.parse(jsonText);
    if (!Array.isArray(parsed)) {
        throw new Error("Format respons Gemini tidak sesuai.");
    }
    return parsed;
}
function buildPrompt(config, categoryInstruction, modeHint) {
    return `
Kamu adalah generator soal psikotes kerja di Indonesia.

Mode latihan: ${config.userType}.
${modeHint}

Jumlah soal yang HARUS kamu buat: ${config.count} soal.
Kategori: ${config.category}.
Tingkat kesulitan keseluruhan: ${config.difficulty}.

${categoryInstruction}

Aturan umum setiap soal:
- Harus terasa seperti soal psikotes resmi (rekrutmen perusahaan).
- Gunakan bahasa Indonesia yang baku atau semi-baku, jelas, dan rapi.
- Selalu sediakan 4 atau 5 pilihan jawaban berlabel "A", "B", "C", "D" dan jika perlu "E".
- HANYA ada satu jawaban yang benar.
- "questionText" cukup ringkas tetapi jelas.
- "explanation" jelaskan:
  - Kenapa jawaban yang benar itu benar.
  - Kenapa pilihan lainnya salah atau kurang tepat.

Return hasil sebagai ARRAY JSON dengan PERSIS ${config.count} objek, TANPA teks lain di luar JSON.

Format tiap item:

{
  "category": string,
  "difficulty": string,
  "questionType": string,
  "questionText": string,
  "options": [
    { "label": "A", "text": string },
    { "label": "B", "text": string },
    ...
  ],
  "correctOptionLabel": string,
  "explanation": string
}
`;
}
async function POST(req) {
    if (!process.env.GEMINI_API_KEY) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: "GEMINI_API_KEY belum di-set di environment."
        }, {
            status: 500
        });
    }
    let body;
    try {
        body = await req.json();
    } catch  {
        return __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: "Payload tidak valid."
        }, {
            status: 400
        });
    }
    const category = body.category ?? "mixed";
    const difficulty = body.difficulty ?? "sulit";
    const userType = body.userType ?? "santai";
    let count = Number(body.count ?? 10);
    if (Number.isNaN(count)) count = 10;
    count = Math.max(1, Math.min(50, count));
    const config = {
        category,
        difficulty,
        userType,
        count
    };
    if (body.sessionId) {
        const existing = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$lib$2f$session$2d$store$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getSession"])(body.sessionId);
        if (existing) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                sessionId: existing.sessionId,
                questions: existing.questions,
                progress: {
                    answers: existing.answers,
                    currentIndex: existing.currentIndex,
                    completed: existing.completed
                },
                config: existing.config,
                source: "resume"
            });
        }
    }
    const cacheKey = buildCacheKey(config);
    const cached = questionCache.get(cacheKey);
    let questions;
    let source = "fresh";
    if (cached && Date.now() - cached.timestamp < CACHE_TTL_MS) {
        questions = cached.data;
        source = "cache";
    } else {
        try {
            questions = await generateQuestions(buildPrompt(config, buildCategoryInstruction(category), buildModeHint(userType)));
            questionCache.set(cacheKey, {
                timestamp: Date.now(),
                data: questions
            });
        } catch (error) {
            console.error("Gemini error:", error);
            const message = error instanceof Error && error.message ? error.message : "Gagal generate soal dari Gemini.";
            return __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: message
            }, {
                status: 500
            });
        }
    }
    const sessionId = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$crypto__$5b$external$5d$__$28$crypto$2c$__cjs$29$__["randomUUID"])();
    const sessionRecord = {
        sessionId,
        questions,
        answers: {},
        currentIndex: 0,
        completed: false,
        config,
        startedAt: Date.now(),
        updatedAt: Date.now()
    };
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$lib$2f$session$2d$store$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["setSession"])(sessionRecord);
    return __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
        sessionId,
        questions,
        progress: {
            answers: {},
            currentIndex: 0,
            completed: false
        },
        config,
        source
    });
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__7d04c317._.js.map