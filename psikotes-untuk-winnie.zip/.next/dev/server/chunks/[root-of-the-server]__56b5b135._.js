module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[project]/psikotes-untuk-winnie/lib/session-store.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getSession",
    ()=>getSession,
    "listSessions",
    ()=>listSessions,
    "setSession",
    ()=>setSession,
    "updateSession",
    ()=>updateSession
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
;
;
const SESSION_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), ".tmp");
const SESSION_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(SESSION_DIR, "session-store.json");
const sessionStore = new Map();
let initialized = false;
let pendingSave = null;
async function ensureInitialized() {
    if (initialized) return;
    initialized = true;
    try {
        const buffer = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].readFile(SESSION_FILE, "utf8");
        const raw = JSON.parse(buffer);
        for (const record of raw){
            sessionStore.set(record.sessionId, record);
        }
    } catch (error) {
        // File may not exist on first run; ignore ENOENT.
        if (error?.code !== "ENOENT") {
            console.error("Failed to load session store:", error);
        }
    }
}
async function persistStore() {
    await ensureInitialized();
    await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].mkdir(SESSION_DIR, {
        recursive: true
    });
    const snapshot = Array.from(sessionStore.values());
    await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].writeFile(SESSION_FILE, JSON.stringify(snapshot, null, 2), "utf8");
}
function schedulePersist() {
    if (pendingSave) return;
    pendingSave = persistStore().catch((error)=>{
        console.error("Failed to persist session store:", error);
    }).finally(()=>{
        pendingSave = null;
    });
}
async function getSession(sessionId) {
    await ensureInitialized();
    return sessionStore.get(sessionId) ?? null;
}
async function setSession(record) {
    await ensureInitialized();
    sessionStore.set(record.sessionId, record);
    schedulePersist();
    return record;
}
async function updateSession(sessionId, updater) {
    await ensureInitialized();
    const current = sessionStore.get(sessionId) ?? null;
    const next = updater(current);
    if (!next) {
        if (sessionStore.has(sessionId)) {
            sessionStore.delete(sessionId);
            schedulePersist();
        }
        return null;
    }
    sessionStore.set(sessionId, next);
    schedulePersist();
    return next;
}
async function listSessions() {
    await ensureInitialized();
    return Array.from(sessionStore.values());
}
}),
"[project]/psikotes-untuk-winnie/app/api/session/[sessionId]/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET,
    "PATCH",
    ()=>PATCH,
    "runtime",
    ()=>runtime
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/psikotes-untuk-winnie/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$lib$2f$session$2d$store$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/psikotes-untuk-winnie/lib/session-store.ts [app-route] (ecmascript)");
;
;
const runtime = "nodejs";
async function GET(_req, { params }) {
    const session = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$lib$2f$session$2d$store$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getSession"])(params.sessionId);
    if (!session) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: "Session tidak ditemukan."
        }, {
            status: 404
        });
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
        sessionId: session.sessionId,
        questions: session.questions,
        progress: {
            answers: session.answers,
            currentIndex: session.currentIndex,
            completed: session.completed
        },
        config: session.config
    });
}
async function PATCH(req, { params }) {
    let body;
    try {
        body = await req.json();
    } catch  {
        return __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: "Payload tidak valid."
        }, {
            status: 400
        });
    }
    const updated = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$lib$2f$session$2d$store$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["updateSession"])(params.sessionId, (record)=>{
        if (!record) {
            return null;
        }
        return {
            ...record,
            answers: body.answers ?? record.answers,
            currentIndex: typeof body.currentIndex === "number" && !Number.isNaN(body.currentIndex) ? body.currentIndex : record.currentIndex,
            completed: typeof body.completed === "boolean" ? body.completed : record.completed,
            updatedAt: Date.now()
        };
    });
    if (!updated) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: "Session tidak ditemukan."
        }, {
            status: 404
        });
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
        sessionId: updated.sessionId,
        progress: {
            answers: updated.answers,
            currentIndex: updated.currentIndex,
            completed: updated.completed
        }
    });
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__56b5b135._.js.map