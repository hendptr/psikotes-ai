module.exports = [
"[project]/psikotes-untuk-winnie/.next-internal/server/app/api/generate-question/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=62acc__next-internal_server_app_api_generate-question_route_actions_a13cc1b9.js.map