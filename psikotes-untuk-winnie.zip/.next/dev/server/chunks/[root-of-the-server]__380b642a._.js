module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/child_process [external] (child_process, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("child_process", () => require("child_process"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/os [external] (os, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[externals]/process [external] (process, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("process", () => require("process"));

module.exports = mod;
}),
"[externals]/util [external] (util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/querystring [external] (querystring, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("querystring", () => require("querystring"));

module.exports = mod;
}),
"[externals]/buffer [external] (buffer, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}),
"[externals]/fs/promises [external] (fs/promises, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs/promises", () => require("fs/promises"));

module.exports = mod;
}),
"[externals]/node:stream [external] (node:stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:stream", () => require("node:stream"));

module.exports = mod;
}),
"[externals]/node:stream/promises [external] (node:stream/promises, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:stream/promises", () => require("node:stream/promises"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/net [external] (net, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("net", () => require("net"));

module.exports = mod;
}),
"[externals]/tls [external] (tls, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("tls", () => require("tls"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[project]/psikotes-untuk-winnie/app/api/generate-questions/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/psikotes-untuk-winnie/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f40$google$2f$genai$2f$dist$2f$node$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/psikotes-untuk-winnie/node_modules/@google/genai/dist/node/index.mjs [app-route] (ecmascript)");
;
;
const ai = new __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f40$google$2f$genai$2f$dist$2f$node$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["GoogleGenAI"]({
    apiKey: process.env.GEMINI_API_KEY
});
function buildCategoryInstruction(category) {
    switch(category){
        case "padanan_kata":
            return `
Jenis soal: PADANAN KATA (hubungan arti).
- Berikan pasangan kata utama, lalu beberapa pasangan kata sebagai pilihan.
- Peserta diminta memilih pasangan yang hubungan katanya PALING MIRIP dengan pasangan utama.
- Contoh gaya (JANGAN dipakai persis): "Dokter : Rumah Sakit = ...".
`;
        case "sinonim_antonim":
            return `
Jenis soal: SINONIM / ANTONIM.
- Berikan satu kata utama.
- Tentukan apakah soal meminta SINONIM atau ANTONIM (pilih salah satu).
- Tulis jelas di soal, misalnya: "Pilih SINONIM yang paling tepat untuk kata berikut".
- Sediakan 4–5 pilihan jawaban.
`;
        case "hafalan_kata":
            return `
Jenis soal: HAFALAN KATA.
- Di awal soal, tampilkan 8–12 kata acak (boleh dibagi beberapa baris).
- Setelah itu beri pertanyaan yang menguji ingatan, misalnya:
  - "Kata mana yang TIDAK ada dalam daftar di atas?"
  - atau "Pasangan kata mana yang muncul berurutan di daftar?"
- Sediakan 4–5 pilihan jawaban.
`;
        case "deret_matematika":
            return `
Jenis soal: DERET MATEMATIKA SULIT.
- Fokus pada deret yang butuh penalaran, bukan hanya pola sederhana.
- Gunakan pola campuran: aritmetika, geometri, pola selang-seling, kombinasi huruf & angka, atau operasi berbeda di posisi ganjil/genap.
- Boleh gunakan LEBIH DARI SATU titik kosong, misalnya: 3, 6, __, 24, __, 96, ...
- Boleh pakai huruf untuk mewakili posisi (A,B,C) selama jelas.
- Pilihan jawaban harus berupa isi titik kosong yang benar (boleh satu nilai, boleh dua nilai seperti "8 dan 48").
`;
        case "mixed":
        default:
            return `
Kategori CAMPURAN:
- Untuk setiap soal, pilih secara acak salah satu dari:
  - padanan_kata
  - sinonim_antonim
  - hafalan_kata
  - deret_matematika (sulit)
- Pastikan field "category" di JSON mencerminkan kategori aktual tiap soal.
`;
    }
}
async function POST(req) {
    if (!process.env.GEMINI_API_KEY) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: "GEMINI_API_KEY belum di-set di environment."
        }, {
            status: 500
        });
    }
    const body = await req.json();
    const category = body.category ?? "mixed";
    const difficulty = body.difficulty ?? "sulit";
    const userType = body.userType ?? "santai";
    // Clamp jumlah soal: 1–50
    let count = Number(body.count ?? 10);
    if (Number.isNaN(count)) count = 10;
    count = Math.max(1, Math.min(50, count));
    const categoryInstruction = buildCategoryInstruction(category);
    const modeHint = userType === "simulasi" ? "Mode ini seperti simulasi tes kerja sungguhan. Soal boleh dibuat agak menekan waktu dan menguji konsentrasi." : userType === "serius" ? "Mode ini fokus untuk belajar serius dan memperkuat konsep psikotes." : "Mode ini lebih santai, tapi tetap gunakan gaya soal psikotes resmi (bukan kuis santai).";
    const prompt = `
Kamu adalah generator soal psikotes kerja di Indonesia.

Mode latihan: ${userType}.
${modeHint}

Jumlah soal yang HARUS kamu buat: ${count} soal.
Kategori: ${category}.
Tingkat kesulitan keseluruhan: ${difficulty}.

${categoryInstruction}

Aturan umum setiap soal:
- Harus terasa seperti soal psikotes resmi (rekrutmen perusahaan).
- Bahasa Indonesia yang baku / semi-baku, jelas dan rapi.
- Selalu sediakan 4 atau 5 pilihan jawaban berlabel "A", "B", "C", "D" dan jika perlu "E".
- HANYA ada satu jawaban yang benar.
- "questionText" cukup ringkas tetapi jelas.
- "explanation" jelaskan:
  - Kenapa jawaban yang benar itu benar.
  - Kenapa pilihan lainnya salah / kurang tepat.

Return hasil sebagai ARRAY JSON dengan PERSIS ${count} objek, TANPA teks lain di luar JSON.

Format tiap item:

{
  "category": string,              // misal: "padanan_kata", "sinonim_antonim", "hafalan_kata", "deret_matematika"
  "difficulty": string,            // misal: "mudah", "sedang", "sulit"
  "questionType": string,          // misal: "padanan_kata_hubungan_arti", dst.
  "questionText": string,          // teks soal
  "options": [
    { "label": "A", "text": string },
    { "label": "B", "text": string },
    ...
  ],
  "correctOptionLabel": string,    // misal: "C"
  "explanation": string            // penjelasan dalam bahasa Indonesia
}
`;
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: "ARRAY",
                    items: {
                        type: "OBJECT",
                        properties: {
                            category: {
                                type: "STRING"
                            },
                            difficulty: {
                                type: "STRING"
                            },
                            questionType: {
                                type: "STRING"
                            },
                            questionText: {
                                type: "STRING"
                            },
                            options: {
                                type: "ARRAY",
                                items: {
                                    type: "OBJECT",
                                    properties: {
                                        label: {
                                            type: "STRING"
                                        },
                                        text: {
                                            type: "STRING"
                                        }
                                    },
                                    required: [
                                        "label",
                                        "text"
                                    ]
                                }
                            },
                            correctOptionLabel: {
                                type: "STRING"
                            },
                            explanation: {
                                type: "STRING"
                            }
                        },
                        required: [
                            "category",
                            "difficulty",
                            "questionType",
                            "questionText",
                            "options",
                            "correctOptionLabel",
                            "explanation"
                        ]
                    }
                }
            }
        });
        const jsonText = response.text;
        const parsed = JSON.parse(jsonText);
        return __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(parsed);
    } catch (error) {
        console.error("Gemini error:", error);
        const message = error instanceof Error && error.message ? error.message : "Gagal generate soal dari Gemini.";
        return __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: message
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__380b642a._.js.map