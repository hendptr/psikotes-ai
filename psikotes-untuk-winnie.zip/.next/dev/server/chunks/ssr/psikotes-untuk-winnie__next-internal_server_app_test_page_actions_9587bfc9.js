module.exports = [
"[project]/psikotes-untuk-winnie/.next-internal/server/app/test/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=psikotes-untuk-winnie__next-internal_server_app_test_page_actions_9587bfc9.js.map