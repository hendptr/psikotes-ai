module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/tty [external] (tty, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("tty", () => require("tty"));

module.exports = mod;
}),
"[externals]/util [external] (util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}),
"[externals]/os [external] (os, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}),
"[externals]/node:path [external] (node:path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:path", () => require("node:path"));

module.exports = mod;
}),
"[externals]/node:path [external] (node:path, cjs) <export default as minpath>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "minpath",
    ()=>__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
}),
"[externals]/node:process [external] (node:process, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:process", () => require("node:process"));

module.exports = mod;
}),
"[externals]/node:process [external] (node:process, cjs) <export default as minproc>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "minproc",
    ()=>__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$process__$5b$external$5d$__$28$node$3a$process$2c$__cjs$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$process__$5b$external$5d$__$28$node$3a$process$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:process [external] (node:process, cjs)");
}),
"[externals]/node:url [external] (node:url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:url", () => require("node:url"));

module.exports = mod;
}),
"[externals]/node:url [external] (node:url, cjs) <export fileURLToPath as urlToPath>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "urlToPath",
    ()=>__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$url__$5b$external$5d$__$28$node$3a$url$2c$__cjs$29$__["fileURLToPath"]
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$url__$5b$external$5d$__$28$node$3a$url$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:url [external] (node:url, cjs)");
}),
"[project]/psikotes-untuk-winnie/app/test/page.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TestPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/psikotes-untuk-winnie/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/psikotes-untuk-winnie/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/psikotes-untuk-winnie/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$react$2d$markdown$2f$lib$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__Markdown__as__default$3e$__ = __turbopack_context__.i("[project]/psikotes-untuk-winnie/node_modules/react-markdown/lib/index.js [app-ssr] (ecmascript) <export Markdown as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$remark$2d$gfm$2f$lib$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/psikotes-untuk-winnie/node_modules/remark-gfm/lib/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$canvas$2d$confetti$2f$dist$2f$confetti$2e$module$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/psikotes-untuk-winnie/node_modules/canvas-confetti/dist/confetti.module.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$recharts$2f$es6$2f$component$2f$ResponsiveContainer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/psikotes-untuk-winnie/node_modules/recharts/es6/component/ResponsiveContainer.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$recharts$2f$es6$2f$chart$2f$PieChart$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/psikotes-untuk-winnie/node_modules/recharts/es6/chart/PieChart.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$recharts$2f$es6$2f$polar$2f$Pie$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/psikotes-untuk-winnie/node_modules/recharts/es6/polar/Pie.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$recharts$2f$es6$2f$component$2f$Cell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/psikotes-untuk-winnie/node_modules/recharts/es6/component/Cell.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
const markdownComponents = {
    p: ({ children })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "mb-3 whitespace-pre-wrap leading-relaxed text-slate-700 last:mb-0",
            children: children
        }, void 0, false, {
            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
            lineNumber: 60,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0)),
    strong: ({ children })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "font-semibold text-slate-900",
            children: children
        }, void 0, false, {
            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
            lineNumber: 64,
            columnNumber: 29
        }, ("TURBOPACK compile-time value", void 0)),
    em: ({ children })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("em", {
            className: "text-slate-700 italic",
            children: children
        }, void 0, false, {
            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
            lineNumber: 65,
            columnNumber: 25
        }, ("TURBOPACK compile-time value", void 0)),
    ul: ({ children })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
            className: "mb-3 ml-4 list-disc space-y-1 text-slate-700 last:mb-0",
            children: children
        }, void 0, false, {
            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
            lineNumber: 67,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0)),
    ol: ({ children })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
            className: "mb-3 ml-4 list-decimal space-y-1 text-slate-700 last:mb-0",
            children: children
        }, void 0, false, {
            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
            lineNumber: 70,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0)),
    li: ({ children })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
            className: "leading-relaxed",
            children: children
        }, void 0, false, {
            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
            lineNumber: 72,
            columnNumber: 25
        }, ("TURBOPACK compile-time value", void 0)),
    blockquote: ({ children })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("blockquote", {
            className: "mb-3 border-l-2 border-slate-200 pl-3 text-slate-600",
            children: children
        }, void 0, false, {
            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
            lineNumber: 74,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0)),
    code: ({ inline, children })=>inline ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
            className: "rounded bg-slate-100 px-1.5 py-0.5 text-[13px] text-slate-700",
            children: children
        }, void 0, false, {
            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
            lineNumber: 80,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("pre", {
            className: "mb-3 overflow-x-auto rounded-2xl border border-slate-200 bg-slate-50 p-3 text-[13px] leading-relaxed text-slate-700 last:mb-0",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                children: children
            }, void 0, false, {
                fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                lineNumber: 85,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
            lineNumber: 84,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
};
const TIMER_RULES = {
    santai: 45,
    serius: 30,
    simulasi: 25,
    tantangan: 15
};
const PIE_COLORS = [
    "#10b981",
    "#f97316",
    "#6b7280"
];
function getTimerForMode(mode) {
    return TIMER_RULES[mode] ?? 30;
}
function buildAnalysis(questions, answers) {
    if (!questions.length) {
        return {
            insights: [],
            message: "Belum ada data yang bisa dianalisis."
        };
    }
    const summary = new Map();
    questions.forEach((question, index)=>{
        const snapshot = answers[index];
        const data = summary.get(question.category) ?? {
            total: 0,
            correct: 0,
            skipped: 0
        };
        data.total += 1;
        if (snapshot?.isCorrect) data.correct += 1;
        if (!snapshot?.selected) data.skipped += 1;
        summary.set(question.category, data);
    });
    const insights = Array.from(summary.entries()).map(([category, stat])=>({
            category,
            accuracy: stat.total ? stat.correct / stat.total : 0,
            skipped: stat.skipped
        })).sort((a, b)=>a.accuracy - b.accuracy);
    const weakest = insights[0];
    let message = "Terus latihan untuk meningkatkan konsistensi pada semua kategori.";
    if (weakest) {
        if (weakest.accuracy < 0.4) {
            message = `Kategori "${weakest.category}" membutuhkan sesi tambahan.`;
        } else if (weakest.accuracy < 0.7) {
            message = `Kategori "${weakest.category}" sudah cukup baik, pertahankan ritmenya.`;
        }
    }
    return {
        insights,
        message
    };
}
function formatSeconds(seconds) {
    const safe = Math.max(0, Math.floor(seconds));
    return `00:${String(safe).padStart(2, "0")}`;
}
function TestPage() {
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const initialConfig = {
        userType: searchParams.get("userType") ?? "serius",
        category: searchParams.get("category") ?? "mixed",
        difficulty: searchParams.get("difficulty") ?? "sulit",
        count: Number(searchParams.get("count") ?? 20)
    };
    const resumeParam = searchParams.get("sessionId");
    const requestConfigRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(initialConfig);
    const [sessionConfig, setSessionConfig] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(initialConfig);
    const [sessionId, setSessionId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [resumeSession, setResumeSession] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(resumeParam);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [questions, setQuestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [answers, setAnswers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({});
    const [currentIndex, setCurrentIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const [viewMode, setViewMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("test");
    const [secondsRemaining, setSecondsRemaining] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(getTimerForMode(initialConfig.userType));
    const [reloadToken, setReloadToken] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const [, setFeedback] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [openExplanation, setOpenExplanation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const timeoutHandledRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(false);
    const geniusCelebratedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(false);
    const total = questions.length;
    const answeredCount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>Object.keys(answers).length, [
        answers
    ]);
    const correctCount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>Object.values(answers).filter((entry)=>entry?.isCorrect).length, [
        answers
    ]);
    const wrongCount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>Object.values(answers).filter((entry)=>entry && entry.isCorrect === false && entry.selected).length, [
        answers
    ]);
    const skippedCount = Math.max(0, answeredCount - correctCount - wrongCount);
    const answeredPercentage = total ? Math.round(answeredCount / total * 100) : 0;
    const currentProgress = total ? Math.round((currentIndex + 1) / total * 100) : 0;
    const accuracy = answeredCount ? Math.round(correctCount / answeredCount * 100) : 0;
    const allAnswered = total > 0 && answeredCount === total;
    const currentQuestion = questions[currentIndex];
    const currentAnswer = answers[currentIndex];
    const pieData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>[
            {
                name: "Benar",
                value: correctCount,
                fill: PIE_COLORS[0]
            },
            {
                name: "Salah",
                value: wrongCount,
                fill: PIE_COLORS[1]
            },
            {
                name: "Lewat",
                value: skippedCount,
                fill: PIE_COLORS[2]
            }
        ].filter((item)=>item.value > 0), [
        correctCount,
        wrongCount,
        skippedCount
    ]);
    const analysis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>buildAnalysis(questions, answers), [
        questions,
        answers
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        timeoutHandledRef.current = false;
        if (viewMode === "test") {
            setSecondsRemaining(getTimerForMode(sessionConfig.userType));
        }
    }, [
        currentIndex,
        sessionConfig.userType,
        viewMode
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        let active = true;
        async function fetchQuestions() {
            setLoading(true);
            setError(null);
            try {
                const payload = {
                    ...requestConfigRef.current,
                    count: requestConfigRef.current.count
                };
                if (resumeSession) {
                    payload.sessionId = resumeSession;
                }
                const res = await fetch("/api/generate-questions", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(payload)
                });
                if (!res.ok) {
                    const data = await res.json().catch(()=>({}));
                    throw new Error(data.error || "Gagal memuat soal.");
                }
                const data = await res.json();
                if (!active) return;
                setSessionId(data.sessionId);
                setQuestions(data.questions);
                setAnswers(data.progress?.answers ?? {});
                setCurrentIndex(data.progress?.currentIndex ?? 0);
                setSessionConfig(data.config);
                requestConfigRef.current = data.config;
                setViewMode(data.progress?.completed ? "results" : "test");
                setSecondsRemaining(getTimerForMode(data.config.userType));
                timeoutHandledRef.current = false;
                geniusCelebratedRef.current = false;
                if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
                ;
                setResumeSession(null);
            } catch (err) {
                if (!active) return;
                setError(err instanceof Error ? err.message : "Terjadi kesalahan.");
            } finally{
                if (active) {
                    setLoading(false);
                }
            }
        }
        fetchQuestions();
        return ()=>{
            active = false;
        };
    }, [
        reloadToken,
        resumeSession,
        router
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (viewMode === "results" && sessionConfig.userType === "tantangan" && accuracy >= 90 && !geniusCelebratedRef.current) {
            geniusCelebratedRef.current = true;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$canvas$2d$confetti$2f$dist$2f$confetti$2e$module$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])({
                particleCount: 200,
                spread: 70,
                origin: {
                    y: 0.25
                },
                scalar: 1.05
            });
        }
    }, [
        accuracy,
        sessionConfig.userType,
        viewMode
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (viewMode !== "test" || loading || !questions.length) {
            return;
        }
        const interval = window.setInterval(()=>{
            setSecondsRemaining((prev)=>Math.max(prev - 1, 0));
        }, 1000);
        return ()=>window.clearInterval(interval);
    }, [
        loading,
        questions.length,
        viewMode
    ]);
    const timerRatio = getTimerForMode(sessionConfig.userType) > 0 ? Math.max(0, secondsRemaining / getTimerForMode(sessionConfig.userType)) : 0;
    const persistProgress = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async (payload)=>{
        if (!sessionId) return;
        try {
            await fetch(`/api/session/${sessionId}`, {
                method: "PATCH",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    answers: payload.answers,
                    currentIndex: payload.currentIndex,
                    completed: payload.completed
                })
            });
        } catch (err) {
            console.error("Gagal menyimpan progres:", err);
        }
    }, [
        sessionId
    ]);
    const handleTimeout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        if (!currentQuestion) return;
        if (answers[currentIndex]) return;
        const nextAnswers = {
            ...answers,
            [currentIndex]: {
                selected: null,
                isCorrect: false,
                timeSpent: getTimerForMode(sessionConfig.userType),
                autoAdvance: true
            }
        };
        const completed = Object.keys(nextAnswers).length === total;
        const nextIndex = currentIndex < total - 1 ? currentIndex + 1 : currentIndex;
        setAnswers(nextAnswers);
        if (currentIndex < total - 1) {
            setCurrentIndex(nextIndex);
        }
        void persistProgress({
            answers: nextAnswers,
            currentIndex: nextIndex,
            completed
        });
        if (completed) {
            setViewMode("results");
        }
    }, [
        answers,
        currentIndex,
        currentQuestion,
        persistProgress,
        sessionConfig.userType,
        total
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (viewMode === "test" && !loading && secondsRemaining === 0 && !timeoutHandledRef.current) {
            timeoutHandledRef.current = true;
            handleTimeout();
        }
    }, [
        handleTimeout,
        loading,
        secondsRemaining,
        viewMode
    ]);
    const handleSelect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((label)=>{
        if (viewMode !== "test" || !currentQuestion || answers[currentIndex]) {
            return;
        }
        const isCorrect = label === currentQuestion.correctOptionLabel;
        const timeSpent = getTimerForMode(sessionConfig.userType) - secondsRemaining;
        const nextAnswers = {
            ...answers,
            [currentIndex]: {
                selected: label,
                isCorrect,
                timeSpent: Math.max(0, timeSpent)
            }
        };
        setAnswers(nextAnswers);
        setFeedback(isCorrect ? "correct" : "wrong");
        if (isCorrect) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$canvas$2d$confetti$2f$dist$2f$confetti$2e$module$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])({
                particleCount: 120,
                spread: 60,
                origin: {
                    y: 0.4
                }
            });
        }
        const completed = Object.keys(nextAnswers).length === total;
        const nextIndex = currentIndex < total - 1 ? currentIndex + 1 : currentIndex;
        void persistProgress({
            answers: nextAnswers,
            currentIndex: nextIndex,
            completed
        });
        if (currentIndex < total - 1) {
            window.setTimeout(()=>{
                setCurrentIndex((prev)=>prev < total - 1 ? prev + 1 : prev);
            }, 360);
        } else if (completed) {
            setViewMode("results");
        }
    }, [
        answers,
        currentIndex,
        currentQuestion,
        persistProgress,
        secondsRemaining,
        sessionConfig.userType,
        total,
        viewMode
    ]);
    const goNext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        if (currentIndex >= total - 1) return;
        const nextIndex = currentIndex + 1;
        setCurrentIndex(nextIndex);
        void persistProgress({
            answers,
            currentIndex: nextIndex,
            completed: allAnswered
        });
    }, [
        allAnswered,
        answers,
        currentIndex,
        persistProgress,
        total
    ]);
    const goPrev = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        if (currentIndex <= 0) return;
        const prevIndex = currentIndex - 1;
        setCurrentIndex(prevIndex);
        void persistProgress({
            answers,
            currentIndex: prevIndex,
            completed: allAnswered
        });
    }, [
        allAnswered,
        answers,
        currentIndex,
        persistProgress
    ]);
    const handleSubmit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        if (!allAnswered) return;
        setViewMode("results");
        void persistProgress({
            answers,
            currentIndex,
            completed: true
        });
    }, [
        allAnswered,
        answers,
        currentIndex,
        persistProgress
    ]);
    const handleReplay = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        setViewMode("test");
        setAnswers({});
        setCurrentIndex(0);
        setSessionId(null);
        setOpenExplanation(null);
        geniusCelebratedRef.current = false;
        setReloadToken((prev)=>prev + 1);
    }, []);
    const handleCopySessionId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        if (!sessionId || typeof navigator === "undefined") return;
        navigator.clipboard.writeText(sessionId).catch(()=>{
            console.warn("Gagal menyalin Session ID.");
        });
    }, [
        sessionId
    ]);
    if (loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mx-auto flex min-h-[70vh] w-full max-w-5xl items-center justify-center px-5",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "rounded-3xl bg-white px-6 py-6 text-sm text-slate-500 shadow-sm",
                children: "Menyiapkan soal dari Gemini 2.5..."
            }, void 0, false, {
                fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                lineNumber: 497,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
            lineNumber: 496,
            columnNumber: 7
        }, this);
    }
    if (error) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mx-auto flex min-h-[70vh] w-full max-w-5xl items-center justify-center px-5",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-4 rounded-3xl bg-white px-6 py-6 shadow-sm",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-rose-500",
                        children: error
                    }, void 0, false, {
                        fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                        lineNumber: 508,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>setReloadToken((prev)=>prev + 1),
                        className: "inline-flex items-center justify-center rounded-full border border-slate-900 px-4 py-2 text-sm font-semibold text-slate-900 transition hover:bg-slate-900 hover:text-white",
                        children: "Coba muat ulang soal"
                    }, void 0, false, {
                        fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                        lineNumber: 509,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                lineNumber: 507,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
            lineNumber: 506,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mx-auto flex w-full max-w-6xl flex-col gap-8 px-5 py-10",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: "rounded-3xl bg-white px-6 py-6 shadow-sm",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col gap-4 md:flex-row md:items-start md:justify-between",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xs uppercase tracking-[0.32em] text-slate-400",
                                    children: sessionConfig.userType === "tantangan" ? "Mode Sprint" : sessionConfig.userType === "simulasi" ? "Simulasi Tes" : sessionConfig.userType === "santai" ? "Tempo Santai" : "Fokus Stabil"
                                }, void 0, false, {
                                    fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                    lineNumber: 526,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                    className: "text-2xl font-semibold text-slate-900 md:text-3xl",
                                    children: viewMode === "results" ? "Rekap latihan" : "Sesi latihan sedang berjalan"
                                }, void 0, false, {
                                    fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                    lineNumber: 535,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-slate-500",
                                    children: [
                                        sessionConfig.category,
                                        " • ",
                                        sessionConfig.difficulty,
                                        " • ",
                                        sessionConfig.count,
                                        " soal"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                    lineNumber: 538,
                                    columnNumber: 13
                                }, this),
                                sessionId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: handleCopySessionId,
                                    className: "inline-flex items-center gap-2 rounded-full border border-slate-200 px-3 py-1 text-xs font-semibold text-slate-600 transition hover:border-slate-900 hover:text-slate-900",
                                    children: [
                                        "Session ID: ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-slate-900",
                                            children: [
                                                sessionId.slice(0, 8),
                                                "…"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                            lineNumber: 547,
                                            columnNumber: 29
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                    lineNumber: 542,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                            lineNumber: 525,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid gap-3 text-xs text-slate-500 sm:grid-cols-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(SummaryCell, {
                                    title: "Terjawab",
                                    value: `${answeredCount}/${total || 0}`
                                }, void 0, false, {
                                    fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                    lineNumber: 552,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(SummaryCell, {
                                    title: "Akurasi",
                                    value: `${accuracy}%`
                                }, void 0, false, {
                                    fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                    lineNumber: 553,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(SummaryCell, {
                                    title: "Progress",
                                    value: `${answeredPercentage}%`
                                }, void 0, false, {
                                    fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                    lineNumber: 554,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                            lineNumber: 551,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                    lineNumber: 524,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                lineNumber: 523,
                columnNumber: 7
            }, this),
            viewMode === "results" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(ResultsView, {
                accuracy: accuracy,
                answers: answers,
                analysis: analysis,
                pieData: pieData,
                questions: questions,
                onReplay: handleReplay,
                onBackHome: ()=>router.push("/"),
                openExplanation: openExplanation,
                setOpenExplanation: setOpenExplanation
            }, void 0, false, {
                fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                lineNumber: 560,
                columnNumber: 9
            }, this) : currentQuestion ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                    className: "grid gap-6 lg:grid-cols-[minmax(0,1.9fr)_minmax(0,1fr)]",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                            className: "rounded-3xl bg-white px-6 py-6 shadow-sm",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex flex-wrap items-center justify-between gap-3",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-sm font-semibold text-slate-500",
                                            children: [
                                                "Soal ",
                                                currentIndex + 1
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                            lineNumber: 576,
                                            columnNumber: 17
                                        }, this),
                                        currentAnswer && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: `rounded-full px-3 py-1 text-xs font-semibold ${currentAnswer.isCorrect ? "bg-emerald-50 text-emerald-600" : currentAnswer.selected ? "bg-rose-50 text-rose-600" : "bg-amber-50 text-amber-600"}`,
                                            children: currentAnswer.isCorrect ? "Benar" : currentAnswer.selected ? "Kurang tepat" : "Lewat"
                                        }, void 0, false, {
                                            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                            lineNumber: 580,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                    lineNumber: 575,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-4 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm text-slate-700",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$react$2d$markdown$2f$lib$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__Markdown__as__default$3e$__["default"], {
                                        remarkPlugins: [
                                            __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$remark$2d$gfm$2f$lib$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
                                        ],
                                        components: markdownComponents,
                                        children: currentQuestion.questionText
                                    }, void 0, false, {
                                        fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                        lineNumber: 599,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                    lineNumber: 598,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-4 space-y-3",
                                    children: currentQuestion.options.map((option)=>{
                                        const answered = Boolean(currentAnswer);
                                        const isSelected = answered && currentAnswer?.selected === option.label;
                                        const isCorrectOption = answered && option.label === currentQuestion.correctOptionLabel;
                                        const isWrongSelection = isSelected && currentAnswer?.isCorrect === false;
                                        let variant = "border-slate-200 bg-white hover:border-slate-400";
                                        if (isCorrectOption) {
                                            variant = "border-emerald-200 bg-emerald-50 text-emerald-700";
                                        } else if (isWrongSelection) {
                                            variant = "border-rose-200 bg-rose-50 text-rose-600";
                                        } else if (isSelected) {
                                            variant = "border-slate-900 bg-slate-900 text-white";
                                        } else if (answered) {
                                            variant = "border-slate-200 bg-slate-50 text-slate-400";
                                        }
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            onClick: ()=>handleSelect(option.label),
                                            disabled: answered,
                                            className: `flex items-center gap-3 rounded-2xl border px-4 py-4 text-left text-sm transition focus:outline-none ${variant}`,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-slate-200 bg-white text-sm font-semibold",
                                                    children: option.label
                                                }, void 0, false, {
                                                    fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                                    lineNumber: 631,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "leading-relaxed",
                                                    children: option.text
                                                }, void 0, false, {
                                                    fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                                    lineNumber: 634,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, option.label, true, {
                                            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                            lineNumber: 624,
                                            columnNumber: 21
                                        }, this);
                                    })
                                }, void 0, false, {
                                    fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                    lineNumber: 604,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-6 flex flex-wrap items-center justify-between gap-3",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-xs text-slate-500",
                                            children: [
                                                "Progress soal ",
                                                currentProgress,
                                                "% • Timer tersisa ",
                                                formatSeconds(secondsRemaining)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                            lineNumber: 641,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex flex-wrap gap-2 text-sm font-semibold",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    onClick: goPrev,
                                                    disabled: currentIndex === 0,
                                                    className: "rounded-full border border-slate-300 px-4 py-2 text-slate-600 transition hover:border-slate-900 hover:text-slate-900 disabled:cursor-not-allowed disabled:opacity-40",
                                                    children: "Sebelumnya"
                                                }, void 0, false, {
                                                    fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                                    lineNumber: 645,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    onClick: handleSubmit,
                                                    disabled: !allAnswered,
                                                    className: "rounded-full border border-slate-900 bg-slate-900 px-4 py-2 text-white transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:bg-slate-300",
                                                    children: "Selesai"
                                                }, void 0, false, {
                                                    fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                                    lineNumber: 653,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    onClick: goNext,
                                                    disabled: currentIndex >= total - 1,
                                                    className: "rounded-full border border-slate-300 px-4 py-2 text-slate-600 transition hover:border-slate-900 hover:text-slate-900 disabled:cursor-not-allowed disabled:opacity-40",
                                                    children: "Selanjutnya"
                                                }, void 0, false, {
                                                    fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                                    lineNumber: 661,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                            lineNumber: 644,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                    lineNumber: 640,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                            lineNumber: 574,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
                            className: "space-y-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "rounded-3xl bg-white px-5 py-5 shadow-sm",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "text-sm font-semibold text-slate-900",
                                            children: "Timer & progres"
                                        }, void 0, false, {
                                            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                            lineNumber: 675,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "mt-3 space-y-2 text-xs text-slate-500",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex justify-between",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            children: "Tersisa"
                                                        }, void 0, false, {
                                                            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                                            lineNumber: 678,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "font-semibold text-slate-900",
                                                            children: formatSeconds(secondsRemaining)
                                                        }, void 0, false, {
                                                            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                                            lineNumber: 679,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                                    lineNumber: 677,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "h-2 w-full rounded-full bg-slate-200",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "h-full rounded-full bg-slate-900 transition-all",
                                                        style: {
                                                            width: `${Math.max(6, timerRatio * 100)}%`
                                                        }
                                                    }, void 0, false, {
                                                        fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                                        lineNumber: 684,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                                    lineNumber: 683,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                            lineNumber: 676,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                    lineNumber: 674,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "rounded-3xl bg-white px-5 py-5 shadow-sm",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "text-sm font-semibold text-slate-900",
                                            children: "Navigasi soal"
                                        }, void 0, false, {
                                            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                            lineNumber: 693,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "mt-3 grid grid-cols-6 gap-2 text-xs",
                                            children: questions.map((_item, index)=>{
                                                const state = answers[index];
                                                const isCurrent = index === currentIndex;
                                                const classes = state ? state.isCorrect ? "border-emerald-200 bg-emerald-50 text-emerald-700" : state.selected ? "border-rose-200 bg-rose-50 text-rose-600" : "border-amber-200 bg-amber-50 text-amber-600" : "border-slate-200 bg-white text-slate-500";
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    onClick: ()=>setCurrentIndex(index),
                                                    className: `flex h-9 w-full items-center justify-center rounded-xl border text-xs font-semibold transition hover:border-slate-900 hover:text-slate-900 ${classes} ${isCurrent ? "ring-2 ring-slate-900" : ""}`,
                                                    children: index + 1
                                                }, index, false, {
                                                    fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                                    lineNumber: 707,
                                                    columnNumber: 23
                                                }, this);
                                            })
                                        }, void 0, false, {
                                            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                            lineNumber: 694,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                    lineNumber: 692,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "rounded-3xl bg-white px-5 py-5 shadow-sm",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "text-sm font-semibold text-slate-900",
                                            children: "Ringkasan cepat"
                                        }, void 0, false, {
                                            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                            lineNumber: 723,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                            className: "mt-3 space-y-2 text-xs text-slate-500",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    children: [
                                                        "• Terjawab benar: ",
                                                        correctCount
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                                    lineNumber: 725,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    children: [
                                                        "• Terjawab salah: ",
                                                        wrongCount
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                                    lineNumber: 726,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    children: [
                                                        "• Dilewati: ",
                                                        skippedCount
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                                    lineNumber: 727,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                            lineNumber: 724,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                    lineNumber: 722,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                            lineNumber: 673,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                    lineNumber: 573,
                    columnNumber: 11
                }, this)
            }, void 0, false) : null
        ]
    }, void 0, true, {
        fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
        lineNumber: 522,
        columnNumber: 5
    }, this);
}
function ResultsView({ accuracy, answers, analysis, pieData, questions, onReplay, onBackHome, openExplanation, setOpenExplanation }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid gap-6 rounded-3xl bg-white px-6 py-6 shadow-sm lg:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)]",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs uppercase tracking-[0.32em] text-slate-400",
                                children: "Skor akhir"
                            }, void 0, false, {
                                fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                lineNumber: 765,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-4xl font-semibold text-slate-900",
                                children: [
                                    accuracy,
                                    "%"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                lineNumber: 766,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm text-slate-500",
                                children: accuracy >= 90 ? "Eksekusi rapi! Pertahankan ritme secepat ini." : accuracy >= 70 ? "Sudah solid. Sisihkan sesi tambahan untuk kategori yang belum maksimal." : "Gunakan hasil ini sebagai pijakan awal, ulangi beberapa mode untuk meningkatkan akurasi."
                            }, void 0, false, {
                                fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                lineNumber: 767,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-wrap gap-2 text-xs",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: onReplay,
                                        className: "inline-flex items-center justify-center rounded-full border border-slate-900 bg-slate-900 px-4 py-2 font-semibold text-white transition hover:bg-slate-800",
                                        children: "Mulai sesi baru"
                                    }, void 0, false, {
                                        fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                        lineNumber: 775,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: onBackHome,
                                        className: "inline-flex items-center justify-center rounded-full border border-slate-300 px-4 py-2 font-semibold text-slate-600 transition hover:border-slate-900 hover:text-slate-900",
                                        children: "Kembali ke beranda"
                                    }, void 0, false, {
                                        fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                        lineNumber: 782,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                lineNumber: 774,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                        lineNumber: 764,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mx-auto h-48 w-full max-w-xs",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$recharts$2f$es6$2f$component$2f$ResponsiveContainer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ResponsiveContainer"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$recharts$2f$es6$2f$chart$2f$PieChart$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["PieChart"], {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$recharts$2f$es6$2f$polar$2f$Pie$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Pie"], {
                                    data: pieData.length ? pieData : [
                                        {
                                            name: "Belum",
                                            value: 1,
                                            fill: "rgba(148,163,184,0.35)"
                                        }
                                    ],
                                    dataKey: "value",
                                    nameKey: "name",
                                    innerRadius: "55%",
                                    outerRadius: "85%",
                                    paddingAngle: 2,
                                    children: (pieData.length ? pieData : [
                                        {
                                            fill: "rgba(148,163,184,0.35)"
                                        }
                                    ]).map((entry, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$recharts$2f$es6$2f$component$2f$Cell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Cell"], {
                                            fill: entry.fill
                                        }, index, false, {
                                            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                            lineNumber: 803,
                                            columnNumber: 19
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                    lineNumber: 794,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                lineNumber: 793,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                            lineNumber: 792,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                        lineNumber: 791,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                lineNumber: 763,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "rounded-3xl bg-white px-6 py-6 shadow-sm",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-sm font-semibold text-slate-900",
                        children: "Analisis kategori"
                    }, void 0, false, {
                        fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                        lineNumber: 812,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs text-slate-500",
                        children: analysis.message
                    }, void 0, false, {
                        fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                        lineNumber: 813,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-4 grid gap-3 md:grid-cols-2",
                        children: analysis.insights.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "rounded-2xl border border-slate-200 px-4 py-3 text-sm text-slate-600",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "font-semibold text-slate-900",
                                        children: item.category
                                    }, void 0, false, {
                                        fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                        lineNumber: 820,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: [
                                            "Akurasi: ",
                                            (item.accuracy * 100).toFixed(0),
                                            "%"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                        lineNumber: 821,
                                        columnNumber: 15
                                    }, this),
                                    item.skipped > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: [
                                            "Lewat karena waktu: ",
                                            item.skipped,
                                            " soal"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                        lineNumber: 822,
                                        columnNumber: 36
                                    }, this)
                                ]
                            }, item.category, true, {
                                fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                lineNumber: 816,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                        lineNumber: 814,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                lineNumber: 811,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "rounded-3xl bg-white px-6 py-6 shadow-sm",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-sm font-semibold text-slate-900",
                        children: "Review soal"
                    }, void 0, false, {
                        fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                        lineNumber: 829,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs text-slate-500",
                        children: "Ketuk kartu untuk membuka pembahasan."
                    }, void 0, false, {
                        fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                        lineNumber: 830,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-4 space-y-3",
                        children: questions.map((question, index)=>{
                            const snapshot = answers[index];
                            const isOpen = openExplanation === index;
                            const status = snapshot?.isCorrect === true ? "border-emerald-200 bg-emerald-50" : snapshot?.selected ? "border-rose-200 bg-rose-50" : "border-slate-200 bg-slate-50";
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `rounded-3xl border ${status} px-4 py-3 transition`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: ()=>setOpenExplanation(isOpen ? null : index),
                                        className: "flex w-full items-center justify-between gap-3 text-left",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-xs uppercase tracking-wide text-slate-400",
                                                        children: [
                                                            "Soal ",
                                                            index + 1
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                                        lineNumber: 850,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "mt-1 text-sm font-semibold text-slate-900",
                                                        children: question.questionType
                                                    }, void 0, false, {
                                                        fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                                        lineNumber: 851,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                                lineNumber: 849,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xs text-slate-500",
                                                children: isOpen ? "Sembunyikan" : "Lihat pembahasan"
                                            }, void 0, false, {
                                                fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                                lineNumber: 855,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                        lineNumber: 844,
                                        columnNumber: 17
                                    }, this),
                                    isOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-3 space-y-3 rounded-2xl border border-slate-200 bg-white p-4 text-sm text-slate-600",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$react$2d$markdown$2f$lib$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__Markdown__as__default$3e$__["default"], {
                                                remarkPlugins: [
                                                    __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$remark$2d$gfm$2f$lib$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
                                                ],
                                                components: markdownComponents,
                                                children: question.questionText
                                            }, void 0, false, {
                                                fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                                lineNumber: 861,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: [
                                                    "Jawaban kamu: ",
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "font-semibold",
                                                        children: snapshot?.selected ?? "Lewat"
                                                    }, void 0, false, {
                                                        fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                                        lineNumber: 865,
                                                        columnNumber: 37
                                                    }, this),
                                                    " • ",
                                                    "Kunci: ",
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "font-semibold text-slate-900",
                                                        children: question.correctOptionLabel
                                                    }, void 0, false, {
                                                        fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                                        lineNumber: 867,
                                                        columnNumber: 30
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                                lineNumber: 864,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$react$2d$markdown$2f$lib$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__Markdown__as__default$3e$__["default"], {
                                                remarkPlugins: [
                                                    __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$remark$2d$gfm$2f$lib$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
                                                ],
                                                components: markdownComponents,
                                                children: question.explanation
                                            }, void 0, false, {
                                                fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                                lineNumber: 869,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                        lineNumber: 860,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, index, true, {
                                fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                                lineNumber: 843,
                                columnNumber: 15
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                        lineNumber: 831,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                lineNumber: 828,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
        lineNumber: 762,
        columnNumber: 5
    }, this);
}
function SummaryCell({ title, value }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-[11px] uppercase tracking-wide text-slate-400",
                children: title
            }, void 0, false, {
                fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                lineNumber: 891,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$psikotes$2d$untuk$2d$winnie$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-lg font-semibold text-slate-900",
                children: value
            }, void 0, false, {
                fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
                lineNumber: 892,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/psikotes-untuk-winnie/app/test/page.tsx",
        lineNumber: 890,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__fc59ee7e._.js.map