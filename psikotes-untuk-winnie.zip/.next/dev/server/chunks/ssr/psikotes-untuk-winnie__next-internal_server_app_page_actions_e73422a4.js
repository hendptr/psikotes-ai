module.exports = [
"[project]/psikotes-untuk-winnie/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=psikotes-untuk-winnie__next-internal_server_app_page_actions_e73422a4.js.map