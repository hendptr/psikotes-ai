module.exports = [
"[project]/psikotes-untuk-winnie/.next-internal/server/app/latihan/[tipe]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=62acc__next-internal_server_app_latihan_%5Btipe%5D_page_actions_debd32d0.js.map