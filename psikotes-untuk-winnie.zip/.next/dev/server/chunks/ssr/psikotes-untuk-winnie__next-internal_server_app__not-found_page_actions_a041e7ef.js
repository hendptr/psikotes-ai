module.exports = [
"[project]/psikotes-untuk-winnie/.next-internal/server/app/_not-found/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=psikotes-untuk-winnie__next-internal_server_app__not-found_page_actions_a041e7ef.js.map