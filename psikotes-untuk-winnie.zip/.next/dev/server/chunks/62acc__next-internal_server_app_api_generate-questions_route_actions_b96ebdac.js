module.exports = [
"[project]/psikotes-untuk-winnie/.next-internal/server/app/api/generate-questions/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=62acc__next-internal_server_app_api_generate-questions_route_actions_b96ebdac.js.map