module.exports = [
"[project]/psikotes-untuk-winnie/.next-internal/server/app/api/session/[sessionId]/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=62acc__next-internal_server_app_api_session_%5BsessionId%5D_route_actions_ffd96ebc.js.map