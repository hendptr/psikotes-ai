var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/session/[sessionId]/route.js")
R.c("server/chunks/7875c_next_73b9451d._.js")
R.c("server/chunks/[root-of-the-server]__56b5b135._.js")
R.c("server/chunks/62acc__next-internal_server_app_api_session_[sessionId]_route_actions_ffd96ebc.js")
R.m("[project]/psikotes-untuk-winnie/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/psikotes-untuk-winnie/app/api/session/[sessionId]/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/psikotes-untuk-winnie/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/psikotes-untuk-winnie/app/api/session/[sessionId]/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
