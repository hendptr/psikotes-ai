(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_67e51508._.js",
  "static/chunks/7875c_next_dist_compiled_react-dom_96e9b84a._.js",
  "static/chunks/7875c_next_dist_compiled_react-server-dom-turbopack_062e639f._.js",
  "static/chunks/7875c_next_dist_compiled_next-devtools_index_16c19d27.js",
  "static/chunks/7875c_next_dist_compiled_7cc44645._.js",
  "static/chunks/7875c_next_dist_client_45b16614._.js",
  "static/chunks/7875c_next_dist_c035b8ca._.js",
  "static/chunks/7875c_@swc_helpers_cjs_91b722ea._.js"
],
    source: "entry"
});
