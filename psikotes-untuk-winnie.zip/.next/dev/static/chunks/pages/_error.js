__turbopack_load_page_chunks__("/_error", [
  "static/chunks/7875c_next_dist_compiled_df64e3b0._.js",
  "static/chunks/7875c_next_dist_shared_lib_d53af99f._.js",
  "static/chunks/7875c_next_dist_client_4cde66ea._.js",
  "static/chunks/7875c_next_dist_ab0bcde9._.js",
  "static/chunks/7875c_next_error_e88b1eda.js",
  "static/chunks/[next]_entry_page-loader_ts_06175df8._.js",
  "static/chunks/7875c_react-dom_38334c8a._.js",
  "static/chunks/7875c_3674d661._.js",
  "static/chunks/[root-of-the-server]__622142fe._.js",
  "static/chunks/psikotes-untuk-winnie_pages__error_2da965e7._.js",
  "static/chunks/turbopack-psikotes-untuk-winnie_pages__error_b55f7bbb._.js"
])
