__turbopack_load_page_chunks__("/_app", [
  "static/chunks/7875c_next_dist_compiled_df64e3b0._.js",
  "static/chunks/7875c_next_dist_shared_lib_ea2b9407._.js",
  "static/chunks/7875c_next_dist_client_4cde66ea._.js",
  "static/chunks/7875c_next_dist_50042698._.js",
  "static/chunks/7875c_next_app_d40d5349.js",
  "static/chunks/[next]_entry_page-loader_ts_6c22b95a._.js",
  "static/chunks/7875c_react-dom_38334c8a._.js",
  "static/chunks/7875c_3674d661._.js",
  "static/chunks/[root-of-the-server]__cb8f2f84._.js",
  "static/chunks/psikotes-untuk-winnie_pages__app_2da965e7._.js",
  "static/chunks/turbopack-psikotes-untuk-winnie_pages__app_3411ee9f._.js"
])
