(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/7875c_micromark-core-commonmark_dev_lib_468bf6b8._.js",
  "static/chunks/7875c_recharts_es6_5a1bbadd._.js",
  "static/chunks/7875c_4debdd04._.js",
  "static/chunks/psikotes-untuk-winnie_app_test_page_tsx_0aacce20._.js"
],
    source: "dynamic"
});
